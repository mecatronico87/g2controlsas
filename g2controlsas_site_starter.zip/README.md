# G2 Control SAS — Static Website (GitHub Pages)

This is a simple, bilingual (ES/EN) static site for https://www.g2controlsas.com

## Edit content
- `assets/site.js` contains the ES/EN text.
- `index.html` contains the layout.
- `assets/style.css` contains styles.
- Replace the logo in `assets/` if needed.

## Contact form (free, no server)
1) Create a free account at https://formspree.io
2) Create a new form, copy the endpoint like: `https://formspree.io/f/xxxxxx`
3) In `index.html`, replace `REPLACE_FORM_ID` in the form `action` URL.

## Deploy (GitHub Pages, free)
1) Create a GitHub account → New repository (public), any name.
2) Upload all files from this folder (drag & drop in GitHub web UI).
3) Repo → Settings → Pages → Build and deployment: **Deploy from a branch** → Branch: **main** (/**root**).
4) In the same Pages screen, set **Custom domain**: `www.g2controlsas.com` (GitHub will create/validate CNAME).

## DNS (at your domain registrar)
- For **www**: create a **CNAME** record — Host: `www` → Target: `<your-github-username>.github.io`
- For the apex `g2controlsas.com`: use **A/ALIAS/ANAME** per GitHub Pages docs, or set a redirect apex → www.

Docs:
- Creating a Pages site: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
- Publishing source: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- Custom domains: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site
- Troubleshooting & HTTPS: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/troubleshooting-custom-domains-and-github-pages
